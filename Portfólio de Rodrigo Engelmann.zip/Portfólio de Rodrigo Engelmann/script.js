// funcionalidade das estrelas (quantidade: 100 e com posições aleatórias)
for (let i = 0; i < 100; i++) {
    criarElementoAleatorio();
}

function criarElementoAleatorio() {
    const elemento = document.createElement('div');
    elemento.className = 'elemento';

    const largura = ((window.innerWidth / document.documentElement.clientWidth) * 100) - 10; // - 10 é o valor q eu coloqueo pra funcionar o programa sem as estrelas interferirem no tamanho horizontal do site
    const altura = ((window.innerHeight / document.documentElement.clientHeight) * 100) - 10;
    console.log(largura)
    console.log(altura)

    const posicaoX = Math.random() * largura;
    const posicaoY = Math.random() * altura;

    elemento.style.left = `${posicaoX}vw`;
    elemento.style.top = `${posicaoY}vh`;

    elemento.style.animationDelay = `${Math.random() * 5}s`;

    document.body.appendChild(elemento);
}











// Sistema para fazer aquele texto no header que manda para outras partes da página:

// Função para rolar para uma altura específica
function scrollToHeight(vhMultiplier) {
    window.scrollTo({
        top: document.documentElement.clientHeight * vhMultiplier, // Rola para o múltiplo de VH
        behavior: 'smooth'
    });
}

// Adicionar eventos de clique para cada parágrafo
document.getElementById("scrollToSobreMim").addEventListener("click", function() {
    scrollToHeight(0.8); // 80vh
});

document.getElementById("scrollToInstituicoesDeEnsino").addEventListener("click", function() {
    scrollToHeight(1.8); // 180vh
});

document.getElementById("scrollToEmpregadoresPrevios").addEventListener("click", function() {
    scrollToHeight(3); // 300vh
});

document.getElementById("scrollToGaleriaDeProjetos").addEventListener("click", function() {
    scrollToHeight(4.4); // 440vh
});

document.getElementById("scrollToHabilidadesTecnicas").addEventListener("click", function() {
    scrollToHeight(5.6); // 560vh
});

document.getElementById("scrollToHabilidadesComportamentais").addEventListener("click", function() {
    scrollToHeight(7.1); // 710vh
});

document.getElementById("scrollToEntreEmContato").addEventListener("click", function() {
    scrollToHeight(9.2); // 920vh
});